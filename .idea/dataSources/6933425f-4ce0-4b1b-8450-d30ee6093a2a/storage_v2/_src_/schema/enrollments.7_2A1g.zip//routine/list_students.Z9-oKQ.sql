create
	definer = root@localhost procedure list_students(IN course_code varchar(10))
begin
	select s.id, s.name
	from students s
		     inner join enrollments e on s.id = e.id
		     inner join courses c on e.code = c.code
	where e.code = course_code;
END;


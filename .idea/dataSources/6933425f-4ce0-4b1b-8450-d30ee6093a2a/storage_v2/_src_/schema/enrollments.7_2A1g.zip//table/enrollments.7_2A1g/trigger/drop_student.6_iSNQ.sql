create definer = root@localhost trigger drop_student
	before delete
	on enrollments
	for each row
BEGIN
	update courses c set c.actual = c.actual - 1 where c.code = old.code;
END;


create definer = root@localhost trigger enroll_student
	after insert
	on enrollments
	for each row
BEGIN
	update courses c set c.actual = c.actual + 1 where c.code = new.code;
END;

